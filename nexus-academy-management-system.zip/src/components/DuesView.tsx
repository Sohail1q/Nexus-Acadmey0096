import React, { useState, useEffect } from 'react';
import {
  Coins,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  CalendarPlus,
  Users,
  Search,
  Clock,
  Sparkles,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { NexusStudent, NexusClass } from '../types';
import { exportToExcelXls } from '../services/cloudSync';
import {
  getPakistanTime,
  getStudentBillingStatus,
  formatYearMonth,
} from '../services/feeAutomation';

interface DuesViewProps {
  students: NexusStudent[];
  classes: NexusClass[];
  currency?: string;
  onAddFee: (student: NexusStudent) => void;
  onBatchAddMonthlyFee?: (className: string, targetMonth?: string) => void;
  onApplyDueMonthlyFees?: () => void;
  onNotification: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DuesView: React.FC<DuesViewProps> = ({
  students,
  classes,
  currency = 'PKR',
  onAddFee,
  onBatchAddMonthlyFee,
  onApplyDueMonthlyFees,
  onNotification,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'outstanding' | 'month_cycle'>('outstanding');

  // Live Pakistan Time
  const [pkt, setPkt] = useState(getPakistanTime());
  useEffect(() => {
    const timer = setInterval(() => {
      setPkt(getPakistanTime());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Batch Monthly Fee Modal
  const [selectedBatchClass, setSelectedBatchClass] = useState('ALL');
  const [batchMonth, setBatchMonth] = useState(pkt.yearMonth);
  const [showBatchModal, setShowBatchModal] = useState(false);

  // Filter students with dues > 0
  const duesStudents = students.filter((s) => (s.dues || 0) > 0);

  const filteredDues = duesStudents.filter((s) => {
    const term = searchTerm.toLowerCase();
    const matchSearch =
      s.name.toLowerCase().includes(term) ||
      s.id.toLowerCase().includes(term) ||
      (s.fatherName && s.fatherName.toLowerCase().includes(term));
    const matchClass = filterClass ? s.className === filterClass : true;
    return matchSearch && matchClass;
  });

  // Calculate billing statuses for all students
  const enrolledStudents = students.filter((s) => !!s.className && (s.monthlyFee || 0) > 0);

  const billingStatusList = enrolledStudents.map((s) => ({
    student: s,
    status: getStudentBillingStatus(s, pkt.yearMonth),
  }));

  const studentsDueForFee = billingStatusList.filter((item) => item.status.isDueForFee);
  const totalPendingNewFee = studentsDueForFee.reduce(
    (acc, item) => acc + item.status.pendingFeeAmount,
    0
  );

  const totalOutstanding = duesStudents.reduce((acc, s) => acc + (s.dues || 0), 0);

  const getFullPhotoUrl = (photoPath?: string) => {
    if (!photoPath) return '';
    if (photoPath.startsWith('http')) return photoPath;
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return `${origin}${photoPath.startsWith('/') ? '' : '/'}${photoPath}`;
  };

  const handleExportExcel = () => {
    if (filteredDues.length === 0) {
      onNotification('No outstanding dues records to export.', 'info');
      return;
    }

    const columns = [
      { header: 'Student ID', width: 90 },
      { header: 'Photo Link', width: 110 },
      { header: 'Student Name', width: 130 },
      { header: 'Father Name', width: 130 },
      { header: 'Guardian Phone', width: 120 },
      { header: 'Class Name', width: 180 },
      { header: 'Monthly Fee', width: 100 },
      { header: 'Last Billed Month', width: 120 },
      { header: 'Outstanding Dues', width: 120 },
      { header: 'Total Paid To Date', width: 120 },
    ];

    const rows = filteredDues.map((s) => {
      const fullPhoto = getFullPhotoUrl(s.photo);
      return [
        { text: s.id },
        {
          text: fullPhoto ? 'View Online Photo' : 'No Photo',
          isLink: !!fullPhoto,
          linkUrl: fullPhoto,
        },
        { text: s.name },
        { text: s.fatherName || s.guardianName || '' },
        { text: s.guardianNumber || '' },
        { text: s.className || 'Unassigned' },
        { text: `${currency} ${(s.monthlyFee || 0).toLocaleString()}` },
        { text: formatYearMonth(s.lastBilledMonth || '') },
        { text: `${currency} ${(s.dues || 0).toLocaleString()}`, isStatus: true },
        { text: `${currency} ${(s.totalPaid || 0).toLocaleString()}` },
      ];
    });

    const dateStr = new Date().toISOString().split('T')[0];
    exportToExcelXls({
      sheetName: 'Outstanding_Dues',
      title: 'Nexus Academy — Outstanding Tuition Dues Report',
      subtitle: `Total Outstanding Balance: ${currency} ${totalOutstanding.toLocaleString()} | Date: ${dateStr}`,
      columns,
      rows,
      filename: `Tuition_Dues_Report_${dateStr}.xls`,
    });

    onNotification(`Exported ${filteredDues.length} dues records to Excel (.xls)!`, 'success');
  };

  const handleRunBatchFee = () => {
    if (!selectedBatchClass) {
      onNotification('Please select a target class for monthly fee addition.', 'error');
      return;
    }

    if (onBatchAddMonthlyFee) {
      onBatchAddMonthlyFee(selectedBatchClass, batchMonth);
    }
    setShowBatchModal(false);
  };

  return (
    <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 sm:p-6 shadow-sm space-y-5">
      {/* Header with Live Pakistan Time and Month Identification Banner */}
      <div className="pb-4 border-b border-slate-200">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-500" /> Tuition Fees &amp; Monthly Cycle Management
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live automated monthly fee identification based on Pakistan Standard Time (PKT).
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            {/* Live PKT Pill */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-900 text-white rounded-lg border border-slate-700 shadow-xs font-mono text-xs"
              title="Live Pakistan Standard Time (Asia/Karachi, UTC+5) — Used for Academy Monthly Fee Cycle"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold text-emerald-300">{pkt.timeString}</span>
              <span className="text-slate-400 hidden sm:inline">|</span>
              <span className="text-slate-200 hidden sm:inline font-sans text-[11px]">
                {pkt.dateString}
              </span>
              <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-sans font-bold border border-emerald-500/30">
                PKT
              </span>
            </div>

            {onBatchAddMonthlyFee && (
              <button
                type="button"
                onClick={() => {
                  setBatchMonth(pkt.yearMonth);
                  setShowBatchModal(true);
                }}
                className="h-9 px-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg inline-flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <CalendarPlus className="w-4 h-4" /> Batch Add Monthly Fee
              </button>
            )}

            <button
              type="button"
              onClick={handleExportExcel}
              className="h-9 px-3.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-lg inline-flex items-center gap-1.5 shadow-sm transition cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" /> Export Excel (.xls)
            </button>
          </div>
        </div>

        {/* Month Identification Status Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-3 border-t border-slate-100">
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-600" /> Current Billing Month (PKT)
            </span>
            <div className="text-base font-extrabold text-slate-900 mt-1">
              {pkt.monthYearName}
            </div>
            <span className="text-[11px] text-slate-500">
              Reference: {pkt.yearMonth} • Live Pakistan Clock
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-amber-500" /> Total Outstanding Dues
            </span>
            <div className="text-base font-extrabold text-red-600 mt-1">
              {currency} {totalOutstanding.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-500">
              Across {duesStudents.length} student(s) with balance
            </span>
          </div>

          <div className="bg-amber-50/70 border border-amber-200 rounded-lg p-3 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wide flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" /> 1-Month Fee Identification
              </span>
              <div className="text-base font-extrabold text-amber-900 mt-1">
                {studentsDueForFee.length === 0 ? (
                  <span className="text-emerald-700 text-sm font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> All Enrolled Students Billed
                  </span>
                ) : (
                  <span>
                    {studentsDueForFee.length} student(s) due (+{currency}{' '}
                    {totalPendingNewFee.toLocaleString()})
                  </span>
                )}
              </div>
            </div>

            {studentsDueForFee.length > 0 && onApplyDueMonthlyFees && (
              <button
                type="button"
                onClick={onApplyDueMonthlyFees}
                className="mt-2 h-7 px-3 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-md inline-flex items-center justify-center gap-1 shadow-xs transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" /> Apply Due Fees to Dues
              </button>
            )}
          </div>
        </div>
      </div>

      {/* View Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('outstanding')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeSubTab === 'outstanding'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Coins className="w-3.5 h-3.5" />
          <span>Outstanding Dues Register ({filteredDues.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('month_cycle')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeSubTab === 'month_cycle'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Monthly Billing Cycle &amp; Month Tracker ({enrolledStudents.length})</span>
          {studentsDueForFee.length > 0 && (
            <span className="ml-1 px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-extrabold">
              {studentsDueForFee.length}
            </span>
          )}
        </button>
      </div>

      {/* SUB-TAB 1: Outstanding Dues Register */}
      {activeSubTab === 'outstanding' && (
        <div className="space-y-4 animate-in fade-in duration-150">
          {/* Filter / Search Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="sm:col-span-2 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search students with pending dues..."
                className="w-full h-10 pl-9 pr-3 bg-white border border-slate-300 rounded-lg text-sm outline-none focus:border-blue-600"
              />
            </div>

            <div>
              <select
                value={filterClass}
                onChange={(e) => setFilterClass(e.target.value)}
                className="w-full h-10 px-3 bg-white border border-slate-300 rounded-lg text-xs sm:text-sm outline-none focus:border-blue-600"
              >
                <option value="">-- All Classes --</option>
                {classes.map((c, idx) => {
                  const displayStr = `${c.teacher} | ${c.category} - ${c.className} (${c.startTime} to ${c.endTime})`;
                  return (
                    <option key={idx} value={displayStr}>
                      {c.category} - {c.className}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>

          {/* Dues Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                  <th className="py-2.5 px-3">ID #</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Father Name</th>
                  <th className="py-2.5 px-3">Guardian Mobile</th>
                  <th className="py-2.5 px-3">Class Option</th>
                  <th className="py-2.5 px-3">Monthly Fee</th>
                  <th className="py-2.5 px-3">Last Billed Month</th>
                  <th className="py-2.5 px-3 text-red-600 font-bold">Outstanding Dues</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDues.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-8 text-center text-slate-400">
                      {duesStudents.length === 0
                        ? 'All student fees are fully cleared! No outstanding dues.'
                        : 'No students matching the current filter.'}
                    </td>
                  </tr>
                ) : (
                  filteredDues.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-2.5 px-3 font-semibold text-blue-600">{s.id}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">{s.name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{s.fatherName || s.guardianName}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-700">{s.guardianNumber || '—'}</td>
                      <td className="py-2.5 px-3">
                        <span className="inline-block px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-50 text-blue-800 max-w-[180px] truncate">
                          {s.className || 'Unassigned'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        {currency} {(s.monthlyFee || 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 text-xs">
                        {formatYearMonth(s.lastBilledMonth || '')}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-red-600">
                        {currency} {s.dues.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          type="button"
                          onClick={() => onAddFee(s)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs transition cursor-pointer"
                        >
                          Receive / Add Fee
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: Monthly Billing Cycle & Month Tracker */}
      {activeSubTab === 'month_cycle' && (
        <div className="space-y-4 animate-in fade-in duration-150">
          <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm text-blue-950">
                Automated Month Identification Engine (Pakistan Standard Time)
              </p>
              <p className="mt-1 leading-relaxed text-slate-700">
                After one month from a student's admission or previous billing cycle, their monthly tuition fee is identified as due.
                Applying fees automatically updates their outstanding dues, logs a billing transaction, and advances their billed month tag so they are never double-billed for the same month.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                  <th className="py-2.5 px-3">Student</th>
                  <th className="py-2.5 px-3">Class Name</th>
                  <th className="py-2.5 px-3">Monthly Tuition</th>
                  <th className="py-2.5 px-3">Admission Date</th>
                  <th className="py-2.5 px-3">Last Billed Month</th>
                  <th className="py-2.5 px-3">Current Status ({pkt.monthYearName})</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {billingStatusList.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No enrolled students found. Register and admit students first.
                    </td>
                  </tr>
                ) : (
                  billingStatusList.map(({ student, status }) => (
                    <tr key={student.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-900">{student.name}</div>
                        <div className="text-[11px] text-blue-600 font-mono">{student.id}</div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-700 max-w-[200px] truncate">
                        {student.className || '—'}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        {currency} {(student.monthlyFee || 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 text-xs">
                        {student.admissionDate || student.lastAdmissionDate || student.registeredAt || '—'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-700 text-xs font-medium">
                        {status.lastBilledMonthName || 'Initial Admission'}
                      </td>
                      <td className="py-2.5 px-3">
                        {status.isDueForFee ? (
                          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                            <span>
                              {status.unbilledMonths.length} Month(s) Due: +{currency}{' '}
                              {status.pendingFeeAmount.toLocaleString()}
                            </span>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Billed for {pkt.monthYearName}</span>
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {status.isDueForFee ? (
                          <button
                            type="button"
                            onClick={() => onAddFee(student)}
                            className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-md shadow-xs transition cursor-pointer"
                            title="Add monthly fee to dues"
                          >
                            Add Month Fee
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onAddFee(student)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-medium rounded-md transition cursor-pointer"
                          >
                            Manage
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Batch Add Monthly Fee Modal */}
      {showBatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 p-6 space-y-4 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <CalendarPlus className="w-5 h-5 text-blue-600" /> Batch Add Monthly Tuition Fee
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Select a target class and billing month. The system will identify enrolled students, add their monthly tuition fee to their outstanding dues, update their billed month tag, and log billing records.
            </p>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Target Billing Month:
              </label>
              <input
                type="month"
                value={batchMonth}
                onChange={(e) => setBatchMonth(e.target.value)}
                className="w-full h-10 px-3 bg-white border border-slate-300 rounded-md text-sm font-semibold outline-none focus:border-blue-600"
              />
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Selected: {formatYearMonth(batchMonth)} (Based on PKT Cycle)
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Target Class:
              </label>
              <select
                value={selectedBatchClass}
                onChange={(e) => setSelectedBatchClass(e.target.value)}
                className="w-full h-10 px-3 bg-white border border-slate-300 rounded-md text-xs sm:text-sm outline-none focus:border-blue-600"
              >
                <option value="ALL">All Enrolled Students (Entire Academy)</option>
                {classes.map((cls, idx) => {
                  const displayStr = `${cls.teacher} | ${cls.category} - ${cls.className} (${cls.startTime} to ${cls.endTime})`;
                  return (
                    <option key={idx} value={displayStr}>
                      {displayStr}
                    </option>
                  );
                })}
              </select>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowBatchModal(false)}
                className="h-10 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleRunBatchFee}
                className="h-10 px-5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow cursor-pointer"
              >
                Apply Monthly Fee Live
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
