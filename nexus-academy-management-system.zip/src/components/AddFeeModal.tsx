import React, { useState } from 'react';
import { Coins, X, Check, PlusCircle, ArrowDownCircle, AlertCircle, Calendar } from 'lucide-react';
import { NexusStudent, ReceiptData } from '../types';

interface AddFeeModalProps {
  student: NexusStudent | null;
  currency?: string;
  onClose: () => void;
  onSubmitFee: (student: NexusStudent, receiptData?: ReceiptData, message?: string) => void;
}

export const AddFeeModal: React.FC<AddFeeModalProps> = ({
  student,
  currency = 'PKR',
  onClose,
  onSubmitFee,
}) => {
  if (!student) return null;

  // Active mode: 'payment' (Receive Payment) or 'charge_monthly' (Add/Charge Monthly Fee to Dues)
  const [mode, setMode] = useState<'payment' | 'charge_monthly'>('payment');

  // Payment fields
  const [payAmount, setPayAmount] = useState<number>(student.dues > 0 ? student.dues : (student.monthlyFee || 0));

  // Monthly fee charge fields
  const [chargeAmount, setChargeAmount] = useState<number>(student.monthlyFee || 1500);
  const [chargeMonth, setChargeMonth] = useState<string>(
    new Date().toLocaleString('default', { month: 'long', year: 'numeric' })
  );
  const [chargeNote, setChargeNote] = useState<string>('Monthly Tuition Fee');

  const oldDues = student.dues || 0;
  const newDuesAfterPay = Math.max(0, oldDues - (payAmount || 0));
  const newDuesAfterCharge = oldDues + (chargeAmount || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (mode === 'payment') {
      if (payAmount <= 0) return;

      const updatedStudent: NexusStudent = {
        ...student,
        dues: newDuesAfterPay,
        totalPaid: (student.totalPaid || 0) + payAmount,
      };

      const receipt: ReceiptData = {
        receiptNo: 'REC-' + Math.floor(100000 + Math.random() * 900000),
        date: new Date().toISOString().split('T')[0],
        studentId: student.id,
        studentName: student.name,
        fatherName: student.fatherName || '',
        className: student.className || 'General Tuition',
        monthlyFee: student.monthlyFee || 0,
        admissionFee: 0,
        prevDues: oldDues,
        paidAmount: payAmount,
        remainingDues: newDuesAfterPay,
      };

      onSubmitFee(
        updatedStudent,
        receipt,
        `Payment of ${currency} ${payAmount.toLocaleString()} recorded for ${student.name}!`
      );
    } else {
      // Add Monthly Fee Charge to Dues
      if (chargeAmount <= 0) return;

      const ymMatch = chargeMonth.match(/\d{4}-\d{2}/);
      const targetYM = ymMatch ? ymMatch[0] : undefined;

      const updatedStudent: NexusStudent = {
        ...student,
        dues: newDuesAfterCharge,
        lastBilledMonth: targetYM || student.lastBilledMonth,
        feeMonthsBilled: targetYM
          ? Array.from(new Set([...(student.feeMonthsBilled || []), targetYM]))
          : student.feeMonthsBilled,
      };

      onSubmitFee(
        updatedStudent,
        undefined,
        `Monthly fee of ${currency} ${chargeAmount.toLocaleString()} (${chargeMonth}) added to ${student.name}'s dues!`
      );
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-200">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Coins className="w-5 h-5 text-emerald-600" /> Fee &amp; Dues Management
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-100 border-b border-slate-200 text-xs font-bold text-center">
          <button
            type="button"
            onClick={() => setMode('payment')}
            className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              mode === 'payment'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ArrowDownCircle className="w-4 h-4" /> Receive Payment
          </button>
          <button
            type="button"
            onClick={() => setMode('charge_monthly')}
            className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              mode === 'charge_monthly'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <PlusCircle className="w-4 h-4" /> Add Monthly Fee
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-600 block mb-1">
              Student Information
            </label>
            <input
              type="text"
              readOnly
              value={`${student.name} (${student.id}) — ${student.className || 'General'}`}
              className="w-full h-10 px-3 bg-slate-100 border border-slate-300 rounded-md text-xs font-bold text-slate-700 truncate"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Current Monthly Fee
              </label>
              <input
                type="text"
                readOnly
                value={`${currency} ${(student.monthlyFee || 0).toLocaleString()}`}
                className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-md text-xs font-semibold text-slate-700"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Current Total Dues
              </label>
              <input
                type="text"
                readOnly
                value={`${currency} ${oldDues.toLocaleString()}`}
                className="w-full h-9 px-3 bg-red-50 border border-red-200 rounded-md text-xs font-bold text-red-600"
              />
            </div>
          </div>

          {mode === 'payment' ? (
            /* Mode A: Receive Payment */
            <div className="space-y-4 animate-in fade-in duration-100">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Payment Amount Received ({currency}) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  value={payAmount || ''}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  placeholder="Enter amount paid"
                  className="w-full h-10 px-3 bg-white border border-slate-300 rounded-md text-sm font-bold text-emerald-700 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                  required
                  autoFocus
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs flex justify-between items-center">
                <span className="text-slate-500">Updated Remaining Dues:</span>
                <strong className={newDuesAfterPay > 0 ? 'text-red-600' : 'text-emerald-600'}>
                  {currency} {newDuesAfterPay.toLocaleString()}
                </strong>
              </div>
            </div>
          ) : (
            /* Mode B: Add / Charge Monthly Fee */
            <div className="space-y-4 animate-in fade-in duration-100">
              <div className="p-3 rounded-lg bg-blue-50/70 border border-blue-200 text-xs text-blue-900 leading-relaxed">
                Add monthly tuition fee to this student's dues for a new month. Dues will update globally and in real-time.
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Monthly Fee Amount to Add ({currency}) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  value={chargeAmount || ''}
                  onChange={(e) => setChargeAmount(parseFloat(e.target.value) || 0)}
                  className="w-full h-10 px-3 bg-white border border-slate-300 rounded-md text-sm font-bold text-blue-700 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Fee Billing Month / Description
                </label>
                <input
                  type="text"
                  value={chargeMonth}
                  onChange={(e) => setChargeMonth(e.target.value)}
                  placeholder="e.g. October 2026 Monthly Fee"
                  className="w-full h-9 px-3 bg-white border border-slate-300 rounded-md text-xs outline-none focus:border-blue-600"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs flex justify-between items-center">
                <span className="text-slate-500">New Total Dues After Addition:</span>
                <strong className="text-red-600 font-extrabold text-sm">
                  {currency} {newDuesAfterCharge.toLocaleString()}
                </strong>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="h-10 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`h-10 px-5 rounded-lg text-white text-xs font-bold inline-flex items-center gap-1.5 shadow transition cursor-pointer ${
                mode === 'payment'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <Check className="w-4 h-4" />
              {mode === 'payment' ? 'Receive & Generate Receipt' : 'Add Monthly Fee to Dues'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
